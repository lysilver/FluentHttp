import http from 'k6/http';
import { check, sleep } from 'k6';

export const options = {
  vus: 100,
  duration: "120s", 
};

const params = {
  headers: {
    'Content-Type': 'application/json',
  },
};

const url = "http://localhost:5086/todos"
export default function () {
  const res = http.get(url, params);
  // check(res, { 'status was 200': (r) => r.status === 200 });
  // sleep(1);
}
